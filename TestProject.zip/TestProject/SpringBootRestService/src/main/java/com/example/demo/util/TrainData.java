package com.example.demo.util;

import java.util.HashMap;
import java.util.Map;

import com.example.demo.models.Train;

public class TrainData {

	public static Map<Long, Train> trainData = new HashMap<>();
	
	static {
		trainData.put(12368l, new Train(12368l, "Vikramshilaexpress", "Superfast", 110l));
		trainData.put(12394l, new Train(12394l, "Samporna Kranti express", "Superfast", 120l));
		trainData.put(12310l, new Train(12310l, "Rajdhani express", "Superfast", 130l));
		trainData.put(12311l, new Train(12311l, "Humsafar express", "Superfast", 130l));
		trainData.put(12312l, new Train(12312l, " Mumbai Rajdhani express", "Superfast", 140l));
	}

}
