package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Train;
import com.example.demo.services.TrainService;
import com.example.demo.util.MyResponse;

@RestController
@RequestMapping("/train")
public class TrainController {

	@Autowired
	TrainService trainService;

	@GetMapping("/check")
	public String checkApi() {
		return "<h1>Live.....!</h1>";
	}

	// @GetMapping("/byTrainNumber")

	@RequestMapping(value = "/byTrainNumber", method = RequestMethod.GET)
	public Train getTrainByTrainNumber(@RequestParam("number") String trainNumber) {
		return trainService.getTrainByTrainNumber(Long.parseLong(trainNumber));
	}

	@GetMapping("/byTrainNumber/{number}")
	public Train getTrainByTrainNumber2(@PathVariable("number") String trainNumber) {
		return trainService.getTrainByTrainNumber(Long.parseLong(trainNumber));
	}

	@GetMapping("/getAllTrains")
	public List<Train> getAllTrains() {
		return trainService.getAllTrain();
	}

	@GetMapping("/getFilterTrains")
	public List<Train> getFilterTrains() {
		return trainService.getFilter();
	}

	@GetMapping("/getAllTrains2")
	public MyResponse getAllTrains2() {
		return new MyResponse(trainService.getAllTrain(), "Result get successsfully ", HttpStatus.OK.value());
	}
	
	@RequestMapping(value ="/addTrain", method = RequestMethod.POST)
	public String addTraing(@ModelAttribute Train train) {
		System.out.println(train);
		return trainService.addTrains(train);
	}
}
