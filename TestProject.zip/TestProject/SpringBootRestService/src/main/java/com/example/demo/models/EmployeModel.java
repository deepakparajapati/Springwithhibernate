package com.example.demo.models;

public class EmployeModel {

	public String empName;
	public String empDesignation;
	public String empSalary;
	public String empAddress;

	public EmployeModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeModel(String empName, String empDesignation, String empSalary, String empAddress) {
		super();
		this.empName = empName;
		this.empDesignation = empDesignation;
		this.empSalary = empSalary;
		this.empAddress = empAddress;
	}

	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}

	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	/**
	 * @return the empDesignation
	 */
	public String getEmpDesignation() {
		return empDesignation;
	}

	/**
	 * @param empDesignation the empDesignation to set
	 */
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	/**
	 * @return the empSalary
	 */
	public String getEmpSalary() {
		return empSalary;
	}

	/**
	 * @param empSalary the empSalary to set
	 */
	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}

	/**
	 * @return the empAddress
	 */
	public String getEmpAddress() {
		return empAddress;
	}

	/**
	 * @param empAddress the empAddress to set
	 */
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	@Override
	public String toString() {
		return "EmployeModel [empName=" + empName + ", empDesignation=" + empDesignation + ", empSalary=" + empSalary
				+ ", empAddress=" + empAddress + "]";
	}

	
}
