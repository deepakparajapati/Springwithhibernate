package com.example.demo.services;

import java.util.List;

import com.example.demo.models.Train;

public interface TrainService {

	Train getTrainByTrainNumber(Long trainNumber);

	List<Train> getAllTrain();
	
	List<Train> getFilter();

	String addTrains(Train train);
}
