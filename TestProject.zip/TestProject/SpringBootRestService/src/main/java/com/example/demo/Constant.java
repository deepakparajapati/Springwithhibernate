package com.example.demo;

/**
 * @author shailendras2
 *
 */
public class Constant {

	public static final String STATUS_ACTIVE = "ACTIVE";
	public static final String STATUS_INACTIVE = "INACTIVE";
	public static final String EMP_SUCCESS_RESPONSE_MESSAGE = "Employee found successfully...!";
}
