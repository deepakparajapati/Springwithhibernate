package com.example.demo.services.impplementation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.demo.models.Train;
import com.example.demo.services.TrainService;
import com.example.demo.util.TrainData;

@Service
public class TrainserviceImpl implements TrainService {

	@Override
	public Train getTrainByTrainNumber(Long trainNumber) {
		
		return TrainData.trainData.get(trainNumber);
	}

	@Override
	public List<Train> getAllTrain() {

		List<Train> trains = new ArrayList<>();

		Map<Long, Train> map = TrainData.trainData;
		for (Map.Entry<Long, Train> m : map.entrySet()) {
			if (true) {

				trains.add(m.getValue());
			}
		}

		// return TrainData.getTrainData().entrySet().stream().filter(check -> check.getKey() > 12311l).map(x->x.getValue()).collect(Collectors.toList());

		return trains;
	}

	@Override
	public List<Train> getFilter() {
		List<Train> trains = new ArrayList<>();

		Map<Long, Train> map = TrainData.trainData;
		for (Map.Entry<Long, Train> m : map.entrySet()) {
			if (m.getValue().trainName.length() > 5) {
				trains.add(m.getValue());
			}
		}
		return trains;
	}


	@Override
	public String addTrains(Train train) {
		TrainData.trainData.put(train.getTrainNumber(), train);
		return "Train Addedd in map successfully....!";
	}

}
