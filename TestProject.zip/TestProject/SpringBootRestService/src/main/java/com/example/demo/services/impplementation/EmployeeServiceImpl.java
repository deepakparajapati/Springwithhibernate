package com.example.demo.services.impplementation;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Constant;
import com.example.demo.domain.Employee;
import com.example.demo.models.EmployeModel;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.services.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@Override
	public String addEmployee(EmployeModel employee) {
		Employee emp=new Employee();
		emp.setEmpName(employee.getEmpName());
		emp.setEmpAddress(employee.getEmpAddress());
		emp.setEmpDesignation(employee.getEmpDesignation());
		emp.setEmpSalary(Double.parseDouble(employee.getEmpSalary()));
		emp.setCreateDate(LocalDate.now());
		emp.setUpdatedDate(LocalDate.now());
		emp.setStatus(Constant.STATUS_ACTIVE);
		employeeRepository.save(emp);
		return "success";
	}

	@Override
	public EmployeModel getEmployeeById(Long emplId) {
		Optional<Employee> emp = employeeRepository.findById(emplId);
		EmployeModel empModel = new EmployeModel(emp.get().getEmpName(), emp.get().getEmpDesignation(), emp.get().getEmpSalary().toString(), emp.get().getEmpAddress());
		return empModel;
	}

	@Override
	public EmployeModel getEmployeeByName(String empName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeModel getEmployeeByAddress(String empAddress) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(EmployeModel employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String removeEmployee(EmployeModel employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeModel> getAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

}
