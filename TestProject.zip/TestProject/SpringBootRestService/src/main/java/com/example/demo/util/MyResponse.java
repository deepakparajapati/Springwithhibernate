package com.example.demo.util;

public class MyResponse {

	public Object object;
	public String messsage;
	public int status;
	public MyResponse(Object object, String messsage, int status) {
		super();
		this.object = object;
		this.messsage = messsage;
		this.status = status;
	}
	public MyResponse() {
		super();
	}
	
}
