package com.example.demo.services;

import java.util.List;

import com.example.demo.models.EmployeModel;

/**
 * This interface is responsible to manage employees. like create new employee,
 * update employee, delete employee etc.
 * 
 * @author shailendras2
 *
 */
public interface EmployeeService {

	/**
	 * @param employee
	 * @return EmployeModel
	 */
	String addEmployee(EmployeModel employee);

	/**
	 * @param emplId
	 * @return EmployeModel
	 */
	EmployeModel getEmployeeById(Long emplId);

	/**
	 * @param empName
	 * @return EmployeModel
	 */
	EmployeModel getEmployeeByName(String empName);

	/**
	 * @param empAddress
	 * @return EmployeModel
	 */
	EmployeModel getEmployeeByAddress(String empAddress);

	/**
	 * @param employee
	 * @return String
	 */
	String updateEmployee(EmployeModel employee);

	/**
	 * @param employee
	 * @return String
	 */
	String removeEmployee(EmployeModel employee);

	/**
	 * @return List<EmployeModel>
	 */
	List<EmployeModel> getAllEmployee();

}
