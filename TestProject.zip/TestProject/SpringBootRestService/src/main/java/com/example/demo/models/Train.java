package com.example.demo.models;

public class Train {

	public Long trainNumber;
	public String trainName;
	public String trainType;
	public Long maxSpeed;

	public Train() {
		super();
	}

	public Train(Long trainNumber, String trainName, String trainType, Long maxSpeed) {
		super();
		this.trainNumber = trainNumber;
		this.trainName = trainName;
		this.trainType = trainType;
		this.maxSpeed = maxSpeed;
	}

	public Long getTrainNumber() {
		return trainNumber;
	}

	public void setTrainNumber(Long trainNumber) {
		this.trainNumber = trainNumber;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getTrainType() {
		return trainType;
	}

	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}

	public Long getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(Long maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	@Override
	public String toString() {
		return "Train [trainNumber=" + trainNumber + ", trainName=" + trainName + ", trainType=" + trainType
				+ ", maxSpeed=" + maxSpeed + "]";
	}
	
}
