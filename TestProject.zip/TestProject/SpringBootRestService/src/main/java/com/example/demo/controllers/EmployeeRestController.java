package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Constant;
import com.example.demo.models.EmployeModel;
import com.example.demo.services.EmployeeService;
import com.example.demo.util.MyResponse;

@RestController
@RequestMapping("/emp")
public class EmployeeRestController {

	@Autowired
	EmployeeService employeeService;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addEmp(@ModelAttribute EmployeModel employees) {
		return employeeService.addEmployee(employees);
	}

	@RequestMapping(value = "/getByEmpId", method = RequestMethod.GET)
	public MyResponse getEmployeeById(@RequestParam("id") Long emplId) {
		EmployeModel employee = employeeService.getEmployeeById(emplId);
		String responseMessage = Constant.EMP_SUCCESS_RESPONSE_MESSAGE;
		int responseStatus = HttpStatus.OK.value();
		return new MyResponse(employee, responseMessage, responseStatus);
	}
}
