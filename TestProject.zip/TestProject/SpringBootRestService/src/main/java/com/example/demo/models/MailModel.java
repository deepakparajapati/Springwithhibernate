package com.example.demo.models;

public class MailModel {

	public Long mailId;
	public String to;
	public String body;
	public String from;
	
	public MailModel(String to, String body, String from) {
		super();
		this.to = to;
		this.body = body;
		this.from = from;
	}
	public MailModel() {
		super();
	}
	public Long getMailId() {
		return mailId;
	}
	public void setMailId(Long mailId) {
		this.mailId = mailId;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	@Override
	public String toString() {
		return "MailModel [mailId=" + mailId + ", to=" + to + ", body=" + body + ", from=" + from + "]";
	}
	
}
